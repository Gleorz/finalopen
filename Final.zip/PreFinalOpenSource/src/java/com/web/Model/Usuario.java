/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author lagh3
 */
@Entity
@Table(name="usuario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name="Usuario.readAll", query="SELECT d FROM Usuario d"),
    @NamedQuery(name="Usuario.findbyAll", query="SELECT d FROM Usuario d WHERE d.FirstName LIKE :first AND d.LastName LIKE :last AND d.Username LIKE :username AND d.departamento.id = :depa"),
    @NamedQuery(name="Usuario.findbyID", query="SELECT d FROM Usuario d WHERE d.id = :id"),
    @NamedQuery(name="Usuario.findbyFirstName", query="SELECT d FROM Usuario d WHERE d.FirstName LIKE :first"),
    @NamedQuery(name="Usuario.findbyLastName", query="SELECT d FROM Usuario d WHERE d.LastName LIKE :last"),
    @NamedQuery(name="Usuario.findbyUsername", query="SELECT d FROM Usuario d WHERE d.Username LIKE :username"),
    @NamedQuery(name="Usuario.search", query="SELECT d FROM Usuario d WHERE d.FirstName LIKE :first AND d.LastName LIKE :last AND d.Username LIKE :username")
})
public class Usuario implements Serializable {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;
    
    @Column(name="firstName")
    private String FirstName;
     
    @Column(name="lastName")
    private String LastName;
    
    @Column(name="username")
    private String Username;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="departamento_id")
    private Departemento departamento;
    
    @ManyToMany
    @JoinTable(name="skill_usuario",
                joinColumns=@JoinColumn(name="usuario_id", referencedColumnName="id"),
                inverseJoinColumns=@JoinColumn(name="skill_id", referencedColumnName="id"))
    private List<Skill> skills;
    
    public Usuario(){}
    
    public Usuario(String first, String last, Departemento depa, List<Skill> skills){
        this.FirstName=first;
        this.LastName=last;
        this.departamento=depa;
        this.skills=skills;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public Departemento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departemento departamento) {
        this.departamento = departamento;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }
    
    
}
