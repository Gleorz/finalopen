/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.Departamento;
import Entities.Empleado;
import Entities.Habilidad;
import java.util.List;

/**
 *
 * @author PC
 */
public interface EmpleadoDAO {
    
    public List<Empleado> getEmpleados();
    public List<Habilidad> getHabilidades();
    public List<Departamento> getDepartamentos();
    public void guardarEmpleado(Empleado e);
    public Habilidad findHabilidad(long id);
    public Departamento findDepartamento(long id);
    
}
