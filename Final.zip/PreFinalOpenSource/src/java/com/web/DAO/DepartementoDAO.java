/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.DAO;

import com.web.Model.Departemento;
import java.util.List;

/**
 *
 * @author lagh3
 */
public interface DepartementoDAO {
    List<Departemento> readAll();
    Departemento findbyID(long id);
}
