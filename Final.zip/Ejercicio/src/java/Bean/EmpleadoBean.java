/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

import DAO.EmpleadoDAO;
import DAO.EmpleadoDAOImp;
import Entities.Departamento;
import Entities.Empleado;
import Entities.Habilidad;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;

import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

/**
 *
 * @author PC
 */
@ManagedBean(name="beane")
@ViewScoped
public class EmpleadoBean {
    
    //DAO
    private EmpleadoDAO dao;
    
    //Listas de selección para los checkbox u otros
    private List<SelectItem> lstHab;
    private List<SelectItem> lstDep;
    
    
    //Listas varias
    private List<Empleado> lstEmpleado;
    //Listas seleccionadas por el usuario en el form
    
    private String[] selectedHab;
    private String selectedDep;
    
    // Lo que se va a guardar, debe inicializarse aquí
    private Empleado newEmp = new Empleado();

    public EmpleadoBean() {
        dao = new EmpleadoDAOImp();
    }
    
    public void Add(){
        Departamento selectedDepart = dao.findDepartamento(Long.parseLong(selectedDep));
        List<Habilidad> selectedHabilidades = new ArrayList<>();
        for(String shab: selectedHab){
            selectedHabilidades.add(dao.findHabilidad(Long.parseLong(shab)));
        }
        
        this.newEmp.setDep(selectedDepart);
        this.newEmp.setLsthab(selectedHabilidades);
        dao.guardarEmpleado(this.newEmp);
        this.newEmp = new Empleado();
    }

    public EmpleadoDAO getDao() {
        return dao;
    }

    public void setDao(EmpleadoDAO dao) {
        this.dao = dao;
    }

    public List<SelectItem> getLstHab() {
        lstHab = new ArrayList<>();
        for(Habilidad hab: dao.getHabilidades()){
            lstHab.add(new SelectItem(hab.getId(), hab.getName()));
            
        }
        
        return lstHab;
    }

    public void setLstHab(List<SelectItem> lstHab) {
        this.lstHab = lstHab;
    }

    public List<SelectItem> getLstDep() {
        lstDep = new ArrayList<>();
        for(Departamento dep: dao.getDepartamentos()){
            lstDep.add(new SelectItem(dep.getId(), dep.getName()));
            
        }
        return lstDep;
    }

    public void setLstDep(List<SelectItem> lstDep) {
        this.lstDep = lstDep;
    }

    public String[] getSelectedHab() {
        return selectedHab;
    }

    public void setSelectedHab(String[] selectedHab) {
        this.selectedHab = selectedHab;
    }

    public String getSelectedDep() {
        return selectedDep;
    }

    public void setSelectedDep(String selectedDep) {
        this.selectedDep = selectedDep;
    }

    public Empleado getNewEmp() {
        return newEmp;
    }

    public void setNewEmp(Empleado newEmp) {
        this.newEmp = newEmp;
    }

    public List<Empleado> getLstEmpleado() {
        lstEmpleado = dao.getEmpleados();
        return lstEmpleado;
    }

    public void setLstEmpleado(List<Empleado> lstEmpleado) {
        this.lstEmpleado = lstEmpleado;
    }
    
    
  
}
