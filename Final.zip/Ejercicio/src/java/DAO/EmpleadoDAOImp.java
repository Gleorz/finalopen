/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entities.Departamento;
import Entities.Empleado;
import Entities.Habilidad;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author PC
 */
public class EmpleadoDAOImp implements EmpleadoDAO{

    private EntityManagerFactory factory;
    private EntityManager manager;

    public EmpleadoDAOImp() {
        factory = Persistence.createEntityManagerFactory("EjercicioPU");
        manager = factory.createEntityManager();
    }
    
    
    
    @Override
    public List<Empleado> getEmpleados() {
        Query q = manager.createNamedQuery("getalle", Empleado.class);
        return (List<Empleado>)q.getResultList();
    }

    @Override
    public List<Habilidad> getHabilidades() {
        Query q = manager.createNamedQuery("getallh", Habilidad.class);
        return (List<Habilidad>)q.getResultList();
    }

    @Override
    public List<Departamento> getDepartamentos() {
        Query q = manager.createNamedQuery("getalld", Departamento.class);
        return (List<Departamento>)q.getResultList();
    }

    @Override
    public void guardarEmpleado(Empleado e) {
        manager.getTransaction().begin();
        manager.persist(e);
        manager.getTransaction().commit();
    }

    @Override
    public Habilidad findHabilidad(long id) {
        return manager.find(Habilidad.class, id);
    }

    @Override
    public Departamento findDepartamento(long id) {
        return manager.find(Departamento.class, id);
    }
    
    
        
}
