/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.DAO;

import com.web.Model.Usuario;
import java.util.List;

/**
 *
 * @author lagh3
 */
public interface UsuarioDAO {
    void insertUser(Usuario obj);
    void deleteUser(Usuario obj);
    Usuario findbyAll(Usuario obj);
    Usuario findbyID(long id);
    List<Usuario> readAllUsers();
    List<Usuario> search(String first, String last, String username);
}
