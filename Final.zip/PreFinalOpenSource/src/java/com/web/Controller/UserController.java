/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.Controller;

import com.web.DAO.DepartamentoDAOImplements;
import com.web.DAO.DepartementoDAO;
import com.web.DAO.SkillDAO;
import com.web.DAO.SkillDAOImplements;
import com.web.DAO.UsuarioDAO;
import com.web.DAO.UsuarioDAOImplements;
import com.web.Model.Departemento;
import com.web.Model.Skill;
import com.web.Model.Usuario;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.model.SelectItem;
import org.primefaces.context.RequestContext;


/**
 *
 * @author lagh3
 */
@ManagedBean(name="user")
public class UserController {
    //DAO´s
    private UsuarioDAO daoUser;
    private DepartementoDAO daoDepa;
    private SkillDAO daoSkill;
    
    //Skills
    private List<SelectItem> skills;
    private String[]selectedSkills;
    
    //TempUser
    private Usuario user;
    
    //Search
    private String Firstname, Lastname, usuario;
    private String depaID;
    
    private List<Usuario> allUsers;
    
    public UserController(){
        daoUser=new UsuarioDAOImplements();
        daoDepa=new DepartamentoDAOImplements();
        daoSkill=new SkillDAOImplements();
        user=new Usuario();
        allUsers=daoUser.readAllUsers();
    }
    
    @SuppressWarnings("empty-statement")
    public void addUser(){
        user.setDepartamento(daoDepa.findbyID(Long.parseLong(depaID)));
        List<Skill> userSkills=new ArrayList<>();
        for(String one : selectedSkills){
            userSkills.add(daoSkill.findbyID(Long.parseLong(one)));
        };
        user.setSkills(userSkills);
        daoUser.insertUser(user);
        reset();
    }
    
    @SuppressWarnings("empty-statement")
    public void deleteUser(){
        user.setDepartamento(daoDepa.findbyID(Long.parseLong(depaID)));
        List<Skill> userSkills=new ArrayList<>();
        for(String one : selectedSkills){
            userSkills.add(daoSkill.findbyID(Long.parseLong(one)));
        };
        user.setSkills(userSkills);
        Usuario temp = daoUser.findbyAll(user);
        if(temp==null)return;
        else daoUser.deleteUser(temp);
        reset();
    }
    
    public void search(){
        allUsers = daoUser.search(Firstname, Lastname, usuario);
    }

    public List<Usuario> getAllUsers() {
        return allUsers;
    }

    public void setAllUsers(List<Usuario> allUsers) {
        this.allUsers = allUsers;
    }
    
    public List<Departemento> getAllDeps(){
        return daoDepa.readAll();
    }

    public Usuario getUser() {
        return user;
    }

    public void setUser(Usuario user) {
        this.user = user;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String Firstname) {
        this.Firstname = Firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String Lastname) {
        this.Lastname = Lastname;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getDepaID() {
        return depaID;
    }

    public void setDepaID(String depaID) {
        this.depaID = depaID;
    }

    public List<SelectItem> getSkills() {
        skills=new ArrayList<>();
        daoSkill.readAll().forEach((obj) -> {
            skills.add(new SelectItem(obj.getId(),obj.getNombre()));
        });
        return skills;
    }

    public void setSkills(List<SelectItem> skills) {
        this.skills = skills;
    }

    public String[] getSelectedSkills() {
        return selectedSkills;
    }

    public void setSelectedSkills(String[] selectedSkills) {
        this.selectedSkills = selectedSkills;
    }
    
    public void reset() {
        RequestContext.getCurrentInstance().reset(":form:txtFirst");
        RequestContext.getCurrentInstance().reset(":form:txtLast");
        RequestContext.getCurrentInstance().reset(":form:txtUser");
        RequestContext.getCurrentInstance().reset(":form:depas");
    }
}
