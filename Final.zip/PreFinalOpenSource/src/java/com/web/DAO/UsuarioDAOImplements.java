/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.DAO;

import com.web.Model.Usuario;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author lagh3
 */
public class UsuarioDAOImplements implements UsuarioDAO {
    
    EntityManager manager;
    
    public UsuarioDAOImplements(){
        manager=Persistence.createEntityManagerFactory("PreFinalOpenSourcePU").createEntityManager();
    }

    @Override
    public void insertUser(Usuario obj) {
        manager.getTransaction().begin();
        manager.persist(obj);
        manager.getTransaction().commit();
    }

    @Override
    public Usuario findbyID(long id) {
        Query q= manager.createNamedQuery("Usuario.findbyID");
        q.setParameter("id", id);
        try{
            return (Usuario)q.getSingleResult();
        }catch(Exception e)
        {
            return null;
        }
    }

    @Override
    public List<Usuario> readAllUsers() {
        Query q= manager.createNamedQuery("Usuario.readAll");
        return q.getResultList();
    }

    @Override
    public List<Usuario> search(String first, String last, String username) {
        if(first.isEmpty() && last.isEmpty() && username.isEmpty()){
            return readAllUsers();
        }
        else{
            if(last.isEmpty() && username.isEmpty()){//solo nombvre
                Query q= manager.createNamedQuery("Usuario.findbyFirstName");
                q.setParameter("first", first);
                return q.getResultList();
            }
            else{
                if(first.isEmpty() && username.isEmpty()){//solo apellido
                    Query q= manager.createNamedQuery("Usuario.findbyLastName");
                    q.setParameter("last", last);
                    return q.getResultList();
                }
                else{
                    if(first.isEmpty() && last.isEmpty()){//solo usuario
                        Query q= manager.createNamedQuery("Usuario.findbyUsername");
                        q.setParameter("username", username);
                        return q.getResultList();
                    }
                }
            }
        }
        Query q= manager.createNamedQuery("Usuario.search");
        q.setParameter("first", first);
        q.setParameter("last", last);
        q.setParameter("username", username);

        return q.getResultList();

    }

    @Override
    public void deleteUser(Usuario obj) {
        manager.getTransaction().begin();;
        manager.remove(obj);
        manager.getTransaction().commit();
    }

    @Override
    public Usuario findbyAll(Usuario obj) {
        Query q= manager.createNamedQuery("Usuario.findbyAll");
        q.setParameter("first", obj.getFirstName());
        q.setParameter("last", obj.getLastName());
        q.setParameter("username", obj.getUsername());
        q.setParameter("depa", obj.getDepartamento().getId());
        //q.setParameter("skills", obj.getSkills());
        try{
            return (Usuario)q.getSingleResult();
        }catch(Exception e)
        {
            return null;
        }
    }
    
}
