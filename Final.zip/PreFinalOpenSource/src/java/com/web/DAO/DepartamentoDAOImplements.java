/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.DAO;

import com.web.Model.Departemento;
import com.web.Model.Usuario;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author lagh3
 */
public class DepartamentoDAOImplements implements DepartementoDAO {
    EntityManager manager;
    
    public DepartamentoDAOImplements(){
        manager=Persistence.createEntityManagerFactory("PreFinalOpenSourcePU").createEntityManager();
    }

    @Override
    public List<Departemento> readAll() {
        Query q= manager.createNamedQuery("Departamento.readAll");
        return q.getResultList();
    }

    @Override
    public Departemento findbyID(long id) {
        Query q= manager.createNamedQuery("Departamento.finbyID");
        q.setParameter("id", id);
        try{
            return (Departemento)q.getSingleResult();
        }catch(Exception e)
        {
            return null;
        }
    }
}
