use prefinalop;
INSERT INTO `prefinalop`.`skill`
(`nombre`)
VALUES
('skill1'),('skill2'),('skill3'),('skill4');

select * from skill;

INSERT INTO `prefinalop`.`departamento`
(`nombre`)
VALUES
('dapa1'),('dapa2'),('dapa3'),('dapa4');

select * from departamento;

select * from usuario;
select * from skill_usuario;